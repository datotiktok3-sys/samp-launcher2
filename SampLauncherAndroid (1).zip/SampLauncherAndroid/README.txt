Сборка APK (на компьютере):
1. Установи Android Studio.
2. File > Open > выбери папку SampLauncherAndroid. Дождись Gradle Sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk. Скинь на телефон и установи
   (разреши установку из неизвестных источников).

Или сразу на телефон: включи "Отладку по USB", подключи телефон, нажми Run в Android Studio.
