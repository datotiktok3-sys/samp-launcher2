package com.example.samplauncher

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView

class MainActivity : Activity() {

    private data class AppItem(val label: String, val pkg: String) {
        override fun toString() = label
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var nick: EditText
    private lateinit var ip: EditText
    private lateinit var port: EditText
    private lateinit var pass: EditText
    private lateinit var apps: Spinner
    private lateinit var status: TextView
    private var items: List<AppItem> = emptyList()

    private val nickRegex = Regex("^[A-Za-z0-9_\\[\\]\$=@.()]{3,24}$")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("launcher", Context.MODE_PRIVATE)
        nick = findViewById(R.id.nick)
        ip = findViewById(R.id.ip)
        port = findViewById(R.id.port)
        pass = findViewById(R.id.pass)
        apps = findViewById(R.id.apps)
        status = findViewById(R.id.status)

        nick.setText(prefs.getString("nick", ""))
        ip.setText(prefs.getString("ip", ""))
        port.setText(prefs.getString("port", "7777"))
        pass.setText(prefs.getString("pass", ""))

        loadApps()
        findViewById<Button>(R.id.play).setOnClickListener { play() }
    }

    private fun loadApps() {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        items = pm.queryIntentActivities(main, 0)
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }

        val adapter = object : ArrayAdapter<AppItem>(this, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.setTextColor(Color.parseColor("#EDEDED"))
                return v
            }
        }
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        apps.adapter = adapter

        val saved = prefs.getString("pkg", null)
        val idx = items.indexOfFirst { it.pkg == saved }
        if (idx >= 0) apps.setSelection(idx)
    }

    private fun play() {
        val n = nick.text.toString().trim()
        val host = ip.text.toString().trim()
        val p = port.text.toString().toIntOrNull()
        val password = pass.text.toString()

        if (!nickRegex.matches(n)) return err("Ник: 3–24 символа (буквы, цифры, _ [ ] \$ = @ . ( ))")
        if (host.isEmpty() || host.contains(' ')) return err("Введи IP сервера")
        if (p == null || p !in 1..65535) return err("Порт: от 1 до 65535")
        val app = apps.selectedItem as? AppItem ?: return err("Выбери клиент игры")

        prefs.edit()
            .putString("nick", n).putString("ip", host).putString("port", p.toString())
            .putString("pass", password).putString("pkg", app.pkg)
            .apply()

        // Копируем адрес в буфер обмена — можно вставить в клиенте вручную
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("server", "$host:$p"))

        val launch = packageManager.getLaunchIntentForPackage(app.pkg)
            ?: return err("Не удалось открыть ${app.label}")
        // Часть клиентов может читать эти параметры; остальные их проигнорируют
        launch.putExtra("nickname", n)
        launch.putExtra("ip", host)
        launch.putExtra("port", p)
        launch.putExtra("password", password)
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        status.setTextColor(Color.parseColor("#6BDB8A"))
        status.text = "Запускаю ${app.label}. Адрес $host:$p скопирован."
        startActivity(launch)
    }

    private fun err(msg: String) {
        status.setTextColor(Color.parseColor("#FF6B6B"))
        status.text = msg
    }
}
